#ifndef ADMINLOGIN_H
#define ADMINLOGIN_H

#include <QDialog>

namespace Ui {
class adminlogin;
}

class adminlogin : public QDialog
{
    Q_OBJECT

public:
    explicit adminlogin(QWidget *parent = nullptr);
    ~adminlogin();

private slots:
    void on_pushButton_clicked();

    void on_label_3_linkActivated(const QString &link);

private:
    Ui::adminlogin *ui;
};

#endif // ADMINLOGIN_H
