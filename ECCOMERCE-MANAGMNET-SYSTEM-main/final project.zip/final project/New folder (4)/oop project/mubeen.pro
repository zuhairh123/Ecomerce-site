QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    add.cpp \
    adminlogin.cpp \
    adminpanel.cpp \
    delet.cpp \
    edit.cpp \
    login.cpp \
    main.cpp \
    mainwindow.cpp \
    options.cpp \
    showdetails.cpp

HEADERS += \
    add.h \
    adminlogin.h \
    adminpanel.h \
    delet.h \
    edit.h \
    login.h \
    mainwindow.h \
    options.h \
    showdetails.h

FORMS += \
    add.ui \
    adminlogin.ui \
    adminpanel.ui \
    delet.ui \
    edit.ui \
    login.ui \
    mainwindow.ui \
    options.ui \
    showdetails.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

RESOURCES += \
    img.qrc
